--[[
    WhateverRoyaleClient - Core.lua
    Main addon initialization and event handling
]]
local addonName, addon = ...

addon.version = "1.0.2"
addon.messageMode = false
-- Create event frame
addon.eventFrame = CreateFrame("Frame")

-- Message prefix (must match WhateverRoyale)
addon.MESSAGE_PREFIX = "WR"

-- Participant lists per session: { [sessionId] = { ["Name-Realm"] = true, ... } }
addon.sessionParticipants = {}

-- Client state for active Simple Dice session
addon.activeSession = {
    sessionId = nil,
    roundNumber = nil,
    rollAmount = nil,
    canRoll = false,
    winLossHistory = {}, -- {round, won, amount, opponent}
    paidEntries = {},    -- Track paid loss entries: {[entryIndex] = true}
    checkpoints = {},    -- Checkpoint markers for partial payments
}

-- Client state for active DeathRoll session
addon.deathRollSession = {
    sessionId = nil,
    roundNumber = nil,
    wagerAmount = nil,
    currentMax = nil,
    currentPlayer = nil,
    canRoll = false,
    phase = nil,  -- "starter_roll", "death_rolling"
    sessionEnded = false,
    winLossHistory = {},
    paidEntries = {},
    checkpoints = {},
}

-- Pending trade state for auto-fill
addon.pendingTrade = {
    active = false,
    opponent = nil,
    amount = 0,
    entries = {},  -- Entry indices being paid
    isDeathRoll = false,  -- Flag to identify which session
}

-- Register lifecycle events
addon.eventFrame:RegisterEvent("ADDON_LOADED")
addon.eventFrame:RegisterEvent("PLAYER_LOGIN")
addon.eventFrame:RegisterEvent("CHAT_MSG_ADDON")

-- Trade events for payment auto-fill
addon.eventFrame:RegisterEvent("TRADE_SHOW")
addon.eventFrame:RegisterEvent("TRADE_CLOSED")
addon.eventFrame:RegisterEvent("UI_INFO_MESSAGE")

-- Main event handler
addon.eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loadedAddonName = ...
        if loadedAddonName == addonName then
            addon:OnLoad()
        end

    elseif event == "PLAYER_LOGIN" then
        addon:OnLogin()

    elseif event == "CHAT_MSG_ADDON" then
        local prefix, message, channel, sender = ...
        if prefix == addon.MESSAGE_PREFIX then
            addon:HandleAddonMessage(message, channel, sender)
        end

    elseif event == "TRADE_SHOW" then
        if addon.OnTradeShow then
            addon:OnTradeShow()
        end

    elseif event == "TRADE_CLOSED" then
        if addon.OnTradeClosed then
            addon:OnTradeClosed()
        end

    elseif event == "UI_INFO_MESSAGE" then
        local messageType = ...
        ---@diagnostic disable-next-line: undefined-global
        if messageType == LE_GAME_ERR_TRADE_COMPLETE then
            if addon.OnTradeComplete then
                addon:OnTradeComplete()
            end
        end
    end
end)

-- Addon loaded handler
function addon:OnLoad()
    -- Register addon message prefix
    local registered = C_ChatInfo.RegisterAddonMessagePrefix(addon.MESSAGE_PREFIX)
    if not registered then
        addon:Warning("Failed to register addon message prefix")
    end
end

-- Player login handler
function addon:OnLogin()
    self.initialized = true

    if addon.CreateSimpleDiceFrame then
        addon:CreateSimpleDiceFrame()
    end

    if addon.CreateDeathRollFrame then
        addon:CreateDeathRollFrame()
    end

    print("|cFF9482C9[WhateverRoyaleClient]|r v" .. addon.version)
end

-- Message functions
function addon:Error(message)
    if addon.messageMode then
        print("|cFFFF0000[WhateverRoyaleClient Error]|r " .. message)
    end
end

function addon:Warning(message)
    if addon.messageMode then
        print("|cFFFFAA00[WhateverRoyaleClient Warning]|r " .. message)
    end
end

function addon:Success(message)
    if addon.messageMode then
        print("|cFF00FF00[WhateverRoyaleClient]|r " .. message)
    end
end

function addon:Info(message)
    --if addon.messageMode then
        print("|cFF9482C9[WhateverRoyaleClient]|r " .. message)
    --end
end

-- Debug function
-- function addon:Debug(message)
--     if WhateverRoyaleDB and WhateverRoyaleDB.settings.debugMode then
--         print("|cFF888888[WhateverRoyale Debug]|r " .. message)
--     end
-- end

-- ============================================================================
-- Addon Message Handling
-- ============================================================================

---Handle incoming addon messages from WhateverRoyale host
---@param message string The message content (format: "TYPE:DATA")
---@param channel string The distribution channel
---@param sender string The sender's name
function addon:HandleAddonMessage(message, channel, sender)
    -- Parse message type and data
    local msgType, data = strsplit(":", message, 2)

    -- Route to specific handlers based on message type
    if msgType == "TEST" then
        addon:Success(string.format("Received test message from %s: %s", sender, data or "(no data)"))

    elseif msgType == "PARTICIPANTS" then
        -- List of participants for a session - data: "sessionId:player1|player2|..."
        local sessionId, playerList = strsplit(":", data, 2)
        addon.sessionParticipants[sessionId] = {}
        if playerList then
            for playerName in playerList:gmatch("[^|]+") do
                addon.sessionParticipants[sessionId][playerName] = true
            end
        end

    elseif msgType == "ROLL_NOW" then
        -- Host started rolling - data format: sessionId:roundNumber:rollAmount:gameType[:wagerAmount]:channel
        local sessionId, roundNumber, rollAmount, gameType, wagerAmount, channel = strsplit(":", data, 6)
        addon:HandleRollNow(sessionId, tonumber(roundNumber), tonumber(rollAmount), gameType, tonumber(wagerAmount), channel)

    elseif msgType == "DR_TURN" then
        -- DeathRoll turn update - data format: sessionId:currentPlayer:expectedMax
        local sessionId, currentPlayer, expectedMax = strsplit(":", data, 3)
        addon:HandleDRTurn(sessionId, currentPlayer, tonumber(expectedMax))

    elseif msgType == "ROUND_END" then
        -- Round completed - data format: sessionId:roundNumber:winner:loser:amount
        local sessionId, roundNumber, winner, loser, amount = strsplit(":", data, 5)
        addon:HandleRoundEnd(sessionId, tonumber(roundNumber), winner, loser, tonumber(amount))

    elseif msgType == "SESSION_END" then
        -- Host closed the session
        local sessionId = data
        addon:HandleSessionEnd(sessionId)
    end
end

-- ============================================================================
-- Game Event Handlers
-- ============================================================================

---Handle ROLL_NOW message - host started rolling phase
---@param sessionId string The session ID
---@param roundNumber number The round number
---@param rollAmount number The amount to roll for
---@param gameType string|nil The game type ("simpleDice" or "deathRoll")
---@param wagerAmount number|nil The wager amount (DeathRoll only)
---@param channel string|nil The channel to post sign-in messages to (defaults to "PARTY")
function addon:HandleRollNow(sessionId, roundNumber, rollAmount, gameType, wagerAmount, channel)
    -- Default to simpleDice for backwards compatibility
    gameType = gameType or "simpleDice"

    -- Only open the client frame for players who are participants in this round
    local playerName = UnitName("player")
    local playerRealm = GetRealmName()
    local playerId = playerName .. "-" .. playerRealm
    local participants = addon.sessionParticipants[sessionId]
    if participants then
        if not (participants[playerId] or participants[playerName]) then
            return  -- Not a participant; don't open the frame
        end
    end

    if gameType == "deathRoll" then
        -- Handle DeathRoll
        addon.deathRollSession.sessionId = sessionId
        addon.deathRollSession.roundNumber = roundNumber
        addon.deathRollSession.wagerAmount = wagerAmount
        addon.deathRollSession.currentMax = rollAmount
        addon.deathRollSession.canRoll = true  -- Everyone rolls 100 in starter phase
        addon.deathRollSession.phase = "starter_roll"
        addon.deathRollSession.currentPlayer = nil
        addon.deathRollSession.sessionEnded = false
        addon.deathRollSession.channel = channel or "PARTY"

        if addon.deathRollFrame then
            addon:UpdateDeathRollUI()
            if addon.UpdateDRWinLossDisplay then
                addon:UpdateDRWinLossDisplay()
            end
            if not addon.deathRollFrame:IsShown() then
                addon.deathRollFrame:Show()
            end
        end

        addon:Info(string.format("Death-Roll started! Wager: %dg - Roll 100 to determine starter", wagerAmount or 0))
    else
        -- Handle Simple Dice
        addon.activeSession.sessionId = sessionId
        addon.activeSession.roundNumber = roundNumber
        addon.activeSession.rollAmount = rollAmount
        addon.activeSession.canRoll = true
        addon.activeSession.roundStatus = "rolling"
        addon.activeSession.sessionEnded = false
        addon.activeSession.channel = channel or "PARTY"

        if addon.simpleDiceFrame then
            addon:UpdateSimpleDiceUI()
            if addon.UpdateWinLossDisplay then
                addon:UpdateWinLossDisplay()
            end
            if not addon.simpleDiceFrame:IsShown() then
                addon.simpleDiceFrame:Show()
            end
        end

        addon:Info(string.format("Round %d started! Roll for %dg", roundNumber, rollAmount))
    end
end

---Handle DR_TURN message - DeathRoll turn update
---@param sessionId string The session ID
---@param currentPlayer string The player whose turn it is
---@param expectedMax number The max value for the next roll
function addon:HandleDRTurn(sessionId, currentPlayer, expectedMax)
    if addon.deathRollSession.sessionId ~= sessionId then return end

    local playerName = UnitName("player")
    local playerRealm = GetRealmName()
    local playerId = playerName .. "-" .. playerRealm

    addon.deathRollSession.currentPlayer = currentPlayer
    addon.deathRollSession.currentMax = expectedMax
    addon.deathRollSession.phase = "death_rolling"

    -- Check if it's our turn
    local isMyTurn = (currentPlayer == playerId or currentPlayer == playerName)
    addon.deathRollSession.canRoll = isMyTurn

    if addon.UpdateDeathRollUI then
        addon:UpdateDeathRollUI()
    end

    if isMyTurn then
        addon:Info(string.format("Your turn! /roll %d", expectedMax))
    end
end

---Handle ROUND_END message - round completed with results
---@param sessionId string The session ID
---@param roundNumber number The round number
---@param winner string The winner's characterId
---@param loser string The loser's characterId
---@param amount number The payout amount
function addon:HandleRoundEnd(sessionId, roundNumber, winner, loser, amount)
    local playerName = UnitName("player")
    local playerRealm = GetRealmName()
    local playerId = playerName .. "-" .. playerRealm

    -- Check if this round affects us (match by full ID or just name)
    local won = (winner == playerId or winner == playerName)
    local lost = (loser == playerId or loser == playerName)

    -- Determine which session this belongs to
    local isDeathRoll = (addon.deathRollSession.sessionId == sessionId)
    local isSimpleDice = (addon.activeSession.sessionId == sessionId)

    if won or lost then
        -- Get opponent name (just the name part, without realm)
        local opponent = won and loser or winner
        local opponentName = strsplit("-", opponent)

        local historyEntry = {
            round = roundNumber,
            won = won,
            amount = won and amount or -amount,
            opponent = opponentName,
        }

        if isDeathRoll then
            table.insert(addon.deathRollSession.winLossHistory, historyEntry)
            if addon.UpdateDRWinLossDisplay then
                addon:UpdateDRWinLossDisplay()
            end
        elseif isSimpleDice then
            table.insert(addon.activeSession.winLossHistory, historyEntry)
            if addon.UpdateWinLossDisplay then
                addon:UpdateWinLossDisplay()
            end
        end

        if won then
            addon:Success(string.format("Round %d: You won %dg!", roundNumber, amount))
        else
            addon:Warning(string.format("Round %d: You lost %dg", roundNumber, amount))
        end
    end

    -- Update session state
    if isDeathRoll then
        addon.deathRollSession.canRoll = false
        addon.deathRollSession.currentPlayer = nil
        if addon.UpdateDeathRollUI then
            addon:UpdateDeathRollUI()
        end
    elseif isSimpleDice then
        addon.activeSession.canRoll = false
        addon.activeSession.roundStatus = "completed"
        if addon.UpdateSimpleDiceUI then
            addon:UpdateSimpleDiceUI()
        end
    end
end

---Handle SESSION_END message - host closed the session
---@param sessionId string The session ID that ended
function addon:HandleSessionEnd(sessionId)
    -- Check SimpleDice session
    if addon.activeSession.sessionId == sessionId then
        addon:Info("Session ended by host")
        addon.activeSession.sessionEnded = true
        if addon.UpdateSimpleDiceUI then
            addon:UpdateSimpleDiceUI()
        end
    end

    -- Check DeathRoll session
    if addon.deathRollSession.sessionId == sessionId then
        addon:Info("Death-Roll ended by host")
        addon.deathRollSession.sessionEnded = true
        addon.deathRollSession.canRoll = false
        if addon.UpdateDeathRollUI then
            addon:UpdateDeathRollUI()
        end
    end
end

---Reset client session state and close window
function addon:ResetClientSession()
    -- Clear participant tracking
    addon.sessionParticipants = {}

    -- Clear SimpleDice session state
    addon.activeSession = {
        sessionId = nil,
        roundNumber = nil,
        rollAmount = nil,
        canRoll = false,
        winLossHistory = {},
        paidEntries = {},
        checkpoints = {},
        roundStatus = nil,
        sessionEnded = false,
    }

    -- Clear DeathRoll session state
    addon.deathRollSession = {
        sessionId = nil,
        roundNumber = nil,
        wagerAmount = nil,
        currentMax = nil,
        currentPlayer = nil,
        canRoll = false,
        phase = nil,
        sessionEnded = false,
        winLossHistory = {},
        paidEntries = {},
        checkpoints = {},
    }

    -- Clear pending trade
    addon.pendingTrade = {
        active = false,
        opponent = nil,
        amount = 0,
        entries = {},
        isDeathRoll = false,
    }

    -- Hide and reset SimpleDice UI
    if addon.simpleDiceFrame then
        addon.simpleDiceFrame:Hide()
        if addon.UpdateSimpleDiceUI then
            addon:UpdateSimpleDiceUI()
        end
        if addon.UpdateWinLossDisplay then
            addon:UpdateWinLossDisplay()
        end
    end

    -- Hide and reset DeathRoll UI
    if addon.deathRollFrame then
        addon.deathRollFrame:Hide()
        if addon.UpdateDeathRollUI then
            addon:UpdateDeathRollUI()
        end
        if addon.UpdateDRWinLossDisplay then
            addon:UpdateDRWinLossDisplay()
        end
    end
end

-- ============================================================================
-- Message Sending
-- ============================================================================

---Send an addon message to the host
---@param messageType string The message type
---@param data string|nil Optional data payload
---@param channel string|nil Channel to send on (default "PARTY")
---@param target string|nil Required for WHISPER channel
function addon:SendAddonMessage(messageType, data, channel, target)
    local message = messageType
    if data and data ~= "" then
        message = messageType .. ":" .. data
    end
    channel = channel or "PARTY"
    C_ChatInfo.SendAddonMessage(addon.MESSAGE_PREFIX, message, channel, target)
end

