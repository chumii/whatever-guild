--[[
    WhateverRoyaleClient - TradeHelper.lua
    Trade automation for paying losses to opponents

    Workflow:
    1. Player clicks unpaid loss entry in UI
    2. We check if target is the opponent
    3. If yes: initiate trade automatically (WoW handles range errors)
    4. If no: prompt player to target the opponent
    5. On TRADE_SHOW: auto-fill gold amount via SetTradeMoney()
    6. Player confirms trade manually (Blizzard restriction)
]]
local addonName, addon = ...

-- ============================================================================
-- Debt Calculation
-- ============================================================================

---Calculate total owed to a specific opponent (aggregates unpaid losses)
---Only counts entries AFTER the last checkpoint for this opponent
---@param opponentName string The opponent's character name
---@return number totalOwed Total gold owed
---@return table entryIndices Indices of unpaid entries
function addon:GetUnpaidDebtTo(opponentName)
    local totalOwed = 0
    local entries = {}
    local checkpoints = addon.activeSession.checkpoints or {}

    -- Find the highest checkpoint index for this opponent
    -- (entries at or before this index are considered "paid up to")
    local lastCheckpointIdx = 0
    for i, entry in ipairs(addon.activeSession.winLossHistory) do
        if entry.opponent == opponentName and checkpoints[i] then
            lastCheckpointIdx = i
        end
    end

    -- Only sum entries AFTER the last checkpoint
    for i, entry in ipairs(addon.activeSession.winLossHistory) do
        if entry.amount < 0
           and entry.opponent == opponentName
           and not addon.activeSession.paidEntries[i]
           and i > lastCheckpointIdx then
            totalOwed = totalOwed + math.abs(entry.amount)
            table.insert(entries, i)
        end
    end

    return totalOwed, entries
end

---Check if player has enough gold
---@param copperNeeded number Amount needed in copper
---@return boolean hasEnough Whether player has enough
---@return number shortfall Amount missing in copper (0 if has enough)
function addon:HasEnoughGold(copperNeeded)
    local playerMoney = GetMoney()
    if playerMoney >= copperNeeded then
        return true, 0
    end
    return false, copperNeeded - playerMoney
end

-- ============================================================================
-- Target Validation
-- ============================================================================

---Check if current target is the specified player
---@param playerName string The player name to check
---@return boolean isTarget True if target matches
function addon:IsTargeting(playerName)
    if not UnitExists("target") then
        return false
    end

    local targetName = UnitName("target")
    return targetName == playerName
end

---Check if target is a player (not NPC)
---@return boolean isPlayer True if target is a player
function addon:IsTargetPlayer()
    if not UnitExists("target") then
        return false
    end

    return UnitIsPlayer("target")
end

-- ============================================================================
-- Trade Initiation
-- ============================================================================

---Initiate payment for a loss entry (aggregates all losses to same opponent)
---@param clickedEntry table The entry that was clicked {opponent, amount, ...}
function addon:InitiatePayment(clickedEntry)
    local opponentName = clickedEntry.opponent

    if not opponentName then
        self:Warning("Cannot determine opponent name")
        return
    end

    -- Aggregate all unpaid losses to this opponent
    local totalOwed, entryIndices = self:GetUnpaidDebtTo(opponentName)

    if totalOwed == 0 then
        self:Info("No unpaid debts to " .. opponentName)
        return
    end

    local copperOwed = totalOwed * 10000  -- Convert gold to copper

    -- Check if player has enough gold
    local hasEnough, shortfall = self:HasEnoughGold(copperOwed)
    if not hasEnough then
        local goldNeeded = math.ceil(shortfall / 10000)
        self:Warning(string.format("Not enough gold! You need %dg more.", goldNeeded))
        return
    end

    -- Store pending trade info (needed for auto-fill on TRADE_SHOW)
    addon.pendingTrade = {
        active = true,
        opponent = opponentName,
        amount = copperOwed,
        entries = entryIndices,
    }

    -- Validate target
    if not self:IsTargeting(opponentName) then
        self:Info(string.format("Target %s first, then click again to pay %dg",
            opponentName, totalOwed))
        addon.pendingTrade.active = false
        return
    end

    if not self:IsTargetPlayer() then
        self:Warning("Target is not a player")
        addon.pendingTrade.active = false
        return
    end

    -- All checks passed - initiate trade (WoW handles range errors automatically)
    self:Info(string.format("Opening trade with %s for %dg...", opponentName, totalOwed))
    InitiateTrade("target")
end

-- ============================================================================
-- Trade Event Handlers
-- ============================================================================

---Handle TRADE_SHOW event - remind player of amount to pay
---Note: SetTradeMoney is a protected function and cannot be called by addons
function addon:OnTradeShow()
    if not addon.pendingTrade or not addon.pendingTrade.active then return end

    local goldAmount = addon.pendingTrade.amount / 10000

    -- Cannot auto-fill trade money (Blizzard protected function)
    -- Just remind the player what amount to enter
    self:Info(string.format("Pay |cFFFFD100%dg|r to %s", goldAmount, addon.pendingTrade.opponent))
end

---Handle trade completion (called when LE_GAME_ERR_TRADE_COMPLETE received)
function addon:OnTradeComplete()
    if not addon.pendingTrade or not addon.pendingTrade.active then return end

    local wasDeathRoll = addon.pendingTrade.isDeathRoll

    -- Mark entries as paid in the correct session
    if wasDeathRoll then
        for _, entryIndex in ipairs(addon.pendingTrade.entries) do
            addon.deathRollSession.paidEntries[entryIndex] = true
        end
    else
        for _, entryIndex in ipairs(addon.pendingTrade.entries) do
            addon.activeSession.paidEntries[entryIndex] = true
        end
    end

    local goldPaid = addon.pendingTrade.amount / 10000
    self:Success(string.format("Paid %dg to %s!", goldPaid, addon.pendingTrade.opponent))

    -- Clear pending trade
    addon.pendingTrade = {
        active = false,
        opponent = nil,
        amount = 0,
        entries = {},
        isDeathRoll = false,
    }

    -- Update display to show checkmarks
    if wasDeathRoll then
        if self.UpdateDRWinLossDisplay then
            self:UpdateDRWinLossDisplay()
        end
    else
        if self.UpdateWinLossDisplay then
            self:UpdateWinLossDisplay()
        end
    end
end

---Handle trade closed (cancelled or completed)
function addon:OnTradeClosed()
    -- Reset pending state if trade was cancelled (not completed)
    -- Note: OnTradeComplete clears active flag, so if still active here = cancelled
    if addon.pendingTrade and addon.pendingTrade.active then
        addon.pendingTrade.active = false
        self:Info("Trade cancelled")
    end
end
