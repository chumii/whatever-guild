--[[
    WhateverRoyaleClient - ChatCommands.lua
    Slash command handling for the client addon
]]
local addonName, addon = ...

-- Register slash commands
SLASH_WHATEVERROYALECLIENT1 = "/wrc"
SLASH_WHATEVERROYALECLIENT2 = "/whateverroyaleclient"

SlashCmdList["WHATEVERROYALECLIENT"] = function(msg)
    local args = {strsplit(" ", msg)}
    local action = string.lower(args[1] or "")

    if action == "" or action == "help" then
        addon:Info("Commands:")
        print("  /wrc show - Show the game window")
        print("  /wrc hide - Hide the game window")
        print("  /wrc reset - Reset session and close window")
        print("  /wrc pay <name> - Pay all debts to a player")
        print("  /wrc help - Show this help")

    elseif action == "show" or action == "open" then
        if addon.simpleDiceFrame then
            addon.simpleDiceFrame:Show()
            addon:Info("Window opened")
        else
            addon:Warning("No active game window")
        end

    elseif action == "hide" or action == "close" then
        if addon.simpleDiceFrame and addon.simpleDiceFrame:IsShown() then
            addon.simpleDiceFrame:Hide()
            addon:Info("Window hidden (use /wrc show to restore)")
        end

    elseif action == "reset" then
        addon:ResetClientSession()
        addon:Info("Session reset")

    elseif action == "pay" then
        local targetName = args[2]
        if not targetName then
            addon:Warning("Usage: /wrc pay <playername>")
            return
        end

        -- Check if trade helper functions are available
        if not addon.GetUnpaidDebtTo or not addon.InitiatePayment then
            addon:Warning("Trade helper not loaded")
            return
        end

        -- Find unpaid debt to this player
        local totalOwed = addon:GetUnpaidDebtTo(targetName)
        if totalOwed == 0 then
            addon:Info("No unpaid debts to " .. targetName)
            return
        end

        -- Initiate payment with a synthetic entry
        addon:InitiatePayment({opponent = targetName, amount = -totalOwed})

    else
        addon:Warning("Unknown command: " .. action .. " (try /wrc help)")
    end
end
