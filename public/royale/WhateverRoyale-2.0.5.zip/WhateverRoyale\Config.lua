--[[
    WhateverRoyale - Config.lua
    Configuration constants and settings
]]

local addonName, addon = ...

-- Configuration constants
addon.config = {
    -- Visual
    colors = {
        primary = "|cFF9482C9",    -- Purple
        success = "|cFF00FF00",    -- Green
        error = "|cFFFF0000",      -- Red
        warning = "|cFFFFAA00",    -- Orange
        gold = "|cFFFFD100",       -- Gold
        white = "|cFFFFFFFF",      -- White
        gray = "|cFF888888",       -- Gray
        reset = "|r"               -- Reset color
    },

    -- Admin characters (only these can access admin settings)
    -- Format: character name (case-sensitive)
    adminCharacters = {
        ["Gandolff"] = true,
        ["Akopalüzenao"] = true,
        ["Gibbronzä"] = true,
    },

    -- Default channel for session monitoring
    defaultChannel = "RAID",

    -- Default game settings
    defaultGameSettings = {
        simpleDice = {
            rollAmount = 25000,
            minPlayers = 2,
            maxPlayers = 40,
        },
        deathRoll = {
            startAmount = 100000,
            minPlayers = 2,
            maxPlayers = 2,
        },
    },

    -- Version
    version = "2.0.0"
}

-- Helper function to get config value
function addon:GetConfig(key)
    return self.config[key]
end
