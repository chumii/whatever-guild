--[[
    WhateverRoyale - Core.lua
    Main addon initialization and event handling
]]

local addonName, addon = ...

-- PixelUI is loaded via libs/PixelUI.lua and stored in addon.PixelUI
local PixelUI = addon.PixelUI

-- Addon info
addon.version = "2.0.5"
addon.loaded = false
addon.initialized = false

-- Create event frame
addon.eventFrame = CreateFrame("Frame")

-- Register lifecycle events
addon.eventFrame:RegisterEvent("ADDON_LOADED")
addon.eventFrame:RegisterEvent("PLAYER_LOGIN")

-- Register CHAT_MSG_SYSTEM for roll detection (always active)
addon.eventFrame:RegisterEvent("CHAT_MSG_SYSTEM")

-- Register CHAT_MSG_ADDON for inter-addon communication
addon.eventFrame:RegisterEvent("CHAT_MSG_ADDON")

-- Register GROUP_ROSTER_UPDATE for sync digest on group join
addon.eventFrame:RegisterEvent("GROUP_ROSTER_UPDATE")

-- Main event handler
addon.eventFrame:SetScript("OnEvent", function(self, event, ...)
    if event == "ADDON_LOADED" then
        local loadedAddonName = ...
        if loadedAddonName == addonName then
            addon:OnLoad()
        end

    elseif event == "PLAYER_LOGIN" then
        addon:OnLogin()

    -- Roll detection
    elseif event == "CHAT_MSG_SYSTEM" then
        local message = ...
        addon:ProcessRollMessage(message)

    -- Channel monitoring for sign-ups (including leader messages)
    elseif event == "CHAT_MSG_PARTY" or
           event == "CHAT_MSG_PARTY_LEADER" or
           event == "CHAT_MSG_RAID" or
           event == "CHAT_MSG_RAID_LEADER" or
           event == "CHAT_MSG_INSTANCE_CHAT" or
           event == "CHAT_MSG_GUILD" then
        local text, playerName = ...
        addon:ProcessChannelMessage(text, playerName)

    -- Addon message communication
    elseif event == "CHAT_MSG_ADDON" then
        local prefix, message, channel, sender = ...
        if addon.HandleAddonMessage then
            addon:HandleAddonMessage(prefix, message, channel, sender)
        end

    -- Sync digest on group roster change (debounced in Sync.lua)
    elseif event == "GROUP_ROSTER_UPDATE" then
        if addon.OnGroupRosterUpdate then
            addon:OnGroupRosterUpdate()
        end
    end
end)

-- Addon loaded handler
function addon:OnLoad()
    -- Initialize SavedVariables with v2.0.0 schema
    WhateverRoyaleDB = WhateverRoyaleDB or {}

    -- Ensure all required top-level fields exist
    WhateverRoyaleDB.version = WhateverRoyaleDB.version or self.version
    WhateverRoyaleDB.schemaVersion = WhateverRoyaleDB.schemaVersion or 3

    -- Ensure settings exist with defaults
    WhateverRoyaleDB.settings = WhateverRoyaleDB.settings or {}
    WhateverRoyaleDB.settings.debugMode = WhateverRoyaleDB.settings.debugMode or false
    WhateverRoyaleDB.settings.errormsgMode = WhateverRoyaleDB.settings.errormsgMode or false
    WhateverRoyaleDB.settings.successmsgMode = WhateverRoyaleDB.settings.successmsgMode or false
    WhateverRoyaleDB.settings.infomsgMode = WhateverRoyaleDB.settings.infomsgMode or false
    WhateverRoyaleDB.settings.warningmsgMode = WhateverRoyaleDB.settings.warningmsgMode or false
    WhateverRoyaleDB.settings.defaultChannel = WhateverRoyaleDB.settings.defaultChannel or "RAID"
    if WhateverRoyaleDB.settings.mergeMainsAndAlts == nil then
        WhateverRoyaleDB.settings.mergeMainsAndAlts = true
    end
    if WhateverRoyaleDB.settings.autoAnnounceResults == nil then
        WhateverRoyaleDB.settings.autoAnnounceResults = true
    end
    if WhateverRoyaleDB.settings.confirmSessionClose == nil then
        WhateverRoyaleDB.settings.confirmSessionClose = true
    end
    if WhateverRoyaleDB.settings.autoShareSessions == nil then
        WhateverRoyaleDB.settings.autoShareSessions = true
    end

    -- Ensure game settings exist
    WhateverRoyaleDB.gameSettings = WhateverRoyaleDB.gameSettings or {}
    WhateverRoyaleDB.gameSettings.simpleDice = WhateverRoyaleDB.gameSettings.simpleDice or {}
    WhateverRoyaleDB.gameSettings.simpleDice.rollAmount =
        WhateverRoyaleDB.gameSettings.simpleDice.rollAmount or 25000
    WhateverRoyaleDB.gameSettings.simpleDice.minPlayers =
        WhateverRoyaleDB.gameSettings.simpleDice.minPlayers or 2
    WhateverRoyaleDB.gameSettings.simpleDice.maxPlayers =
        WhateverRoyaleDB.gameSettings.simpleDice.maxPlayers or 40

    -- Initialize deathRoll settings if missing
    WhateverRoyaleDB.gameSettings.deathRoll = WhateverRoyaleDB.gameSettings.deathRoll or {}
    WhateverRoyaleDB.gameSettings.deathRoll.startAmount =
        WhateverRoyaleDB.gameSettings.deathRoll.startAmount or addon.config.defaultGameSettings.deathRoll.startAmount
    WhateverRoyaleDB.gameSettings.deathRoll.minPlayers = 2
    WhateverRoyaleDB.gameSettings.deathRoll.maxPlayers = 2

    -- Ensure metadata exists
    WhateverRoyaleDB.metadata = WhateverRoyaleDB.metadata or {}
    WhateverRoyaleDB.metadata.lastSessionCounter =
        WhateverRoyaleDB.metadata.lastSessionCounter or 0
    WhateverRoyaleDB.metadata.lastSessionTimestamp =
        WhateverRoyaleDB.metadata.lastSessionTimestamp or 0
    WhateverRoyaleDB.metadata.totalSessionsCreated =
        WhateverRoyaleDB.metadata.totalSessionsCreated or 0
    WhateverRoyaleDB.metadata.installDate =
        WhateverRoyaleDB.metadata.installDate or time()

    -- Ensure sessions and characters tables exist
    WhateverRoyaleDB.sessions = WhateverRoyaleDB.sessions or {}
    WhateverRoyaleDB.characters = WhateverRoyaleDB.characters or {}

    -- Run migration if needed
    self:MigrateDatabase()

    -- Handle crash recovery: mark any active sessions as abandoned
    self:RecoverAbandonedSessions()

    -- Rebuild character stats from all sessions to ensure consistency
    -- (catches cases where stats were out of sync, e.g. after crash recovery)
    self:RebuildAllCharacterStats()

    self.loaded = true

    if WhateverRoyaleDB.settings.debugMode then
        print("|cFF9482C9[WhateverRoyale]|r Addon loaded (Debug Mode)")
    end
end

-- Player login handler
function addon:OnLogin()
    self.initialized = true

    -- PixelUI is loaded synchronously, so we can create the UI directly
    if addon.CreateMainFrame then
        addon:CreateMainFrame()
    end

    -- Welcome message
    print("|cFF9482C9[WhateverRoyale]|r Type |cFFFFD100/wr open|r to open.")

    -- Send sync digest shortly after login if already grouped
    C_Timer.After(5, function()
        if addon.SendSyncDigest then
            addon:SendSyncDigest()
        end
    end)
end

-- Message functions
function addon:Error(message)
    if WhateverRoyaleDB and WhateverRoyaleDB.settings.errormsgMode then
        print("|cFFFF0000[WhateverRoyale Error]|r " .. message)
    end
end

function addon:Warning(message)
    if WhateverRoyaleDB and WhateverRoyaleDB.settings.warningmsgMode then
        print("|cFFFFAA00[WhateverRoyale Warning]|r " .. message)
    end
end

function addon:Success(message)
    if WhateverRoyaleDB and WhateverRoyaleDB.settings.successmsgMode then
        print("|cFF00FF00[WhateverRoyale]|r " .. message)
    end
end

function addon:Info(message)
    if WhateverRoyaleDB and WhateverRoyaleDB.settings.infomsgMode then
        print("|cFF9482C9[WhateverRoyale]|r " .. message)
    end
end

-- Debug function
function addon:Debug(message)
    if WhateverRoyaleDB and WhateverRoyaleDB.settings.debugMode then
        print("|cFF888888[WhateverRoyale Debug]|r " .. message)
    end
end

-- Check if current character is an admin
function addon:IsAdmin()
    local playerName = UnitName("player")
    return self.config.adminCharacters[playerName] == true
end
