--[[
    WhateverRoyale - Export.lua
    Session export for web import (Vercel / Supabase).

    Two export types:
      WR1!  – session bundle (sessions + slim character records)
      WRC1! – character-only (linkage/identity, no sessions)

    Flow: Build*Payload → Encode*ExportString → show string in UI popup.
]]

local addonName, addon = ...

local EXPORT_FORMAT       = "WhateverRoyale-Export"
local EXPORT_VERSION      = 1
local EXPORT_PREFIX       = "WR1!"

local CHAR_EXPORT_FORMAT  = "WhateverRoyale-CharExport"
local CHAR_EXPORT_VERSION = 1
local CHAR_EXPORT_PREFIX  = "WRC1!"

local WARN_BYTES = 60000   -- soft warning threshold; export still proceeds

local function GetLibs()
    local ld = LibStub and LibStub("LibDeflate",   true)
    local ls = LibStub and LibStub("LibSerialize", true)
    return ld, ls
end

-- Shared encode pipeline. Returns (prefixed_string, nil|"warn_size") or (nil, errorMsg).
local function EncodePayload(payload, prefix)
    local ld, ls = GetLibs()
    if not ld or not ls then
        return nil, "LibDeflate / LibSerialize nicht verfügbar"
    end

    local serialized = ls:Serialize(payload)
    if not serialized then return nil, "Serialisierung fehlgeschlagen" end

    local compressed = ld:CompressDeflate(serialized, {level = 9})
    if not compressed then return nil, "Komprimierung fehlgeschlagen" end

    local encoded = ld:EncodeForPrint(compressed)
    if not encoded then return nil, "Encoding fehlgeschlagen" end

    local result = prefix .. encoded
    if #result > WARN_BYTES then
        return result, "warn_size"
    end
    return result, nil
end

-- Collects slim character records for export.
--   sessionIds  table|nil  when provided, session participants are added too
-- Always includes all linked chars (main/alt). sessionIds adds unlinked
-- participants so the website can display names for every session entry.
local function CollectExportCharacters(sessionIds)
    local seen   = {}
    local result = {}

    local function addChar(characterId)
        if seen[characterId] then return end
        seen[characterId] = true
        local c = WhateverRoyaleDB.characters and WhateverRoyaleDB.characters[characterId]
        if c then
            result[#result + 1] = {
                characterId   = c.characterId,
                name          = c.name,
                realm         = c.realm,
                characterType = c.characterType,
                mainCharacter = c.mainCharacter,
            }
        else
            -- Participant seen in session rolls but no character record yet
            local name, realm = strsplit("-", characterId)
            result[#result + 1] = {
                characterId   = characterId,
                name          = name  or characterId,
                realm         = realm or "",
                characterType = "unlinked",
                mainCharacter = nil,
            }
        end
    end

    -- Always export the full linkage topology
    if WhateverRoyaleDB.characters then
        for charId, char in pairs(WhateverRoyaleDB.characters) do
            if char.characterType == "main" or char.characterType == "alt" then
                addChar(charId)
            end
        end
    end

    -- For session exports: also include every participant so names resolve
    if sessionIds and WhateverRoyaleDB.sessions then
        for _, sid in ipairs(sessionIds) do
            local s = WhateverRoyaleDB.sessions[sid]
            if s then
                for charId in pairs(s.participants or {}) do
                    addChar(charId)
                end
                for _, round in pairs(s.rounds or {}) do
                    for charId in pairs(round.signedUp or {}) do
                        addChar(charId)
                    end
                end
            end
        end
    end

    return result
end

-- Returns a versioned session+character payload table for the given session IDs.
function addon:BuildExportPayload(sessionIds)
    local sessions = {}
    for _, sid in ipairs(sessionIds) do
        local s = WhateverRoyaleDB.sessions[sid]
        if s then
            sessions[#sessions + 1] = s
        end
    end
    return {
        format        = EXPORT_FORMAT,
        formatVersion = EXPORT_VERSION,
        schemaVersion = WhateverRoyaleDB.schemaVersion,
        addonVersion  = addon.version,
        exportedAt    = time(),
        exportedBy    = self:GetCurrentCharacterId(),
        sessions      = sessions,
        characters    = CollectExportCharacters(sessionIds),
    }
end

-- Returns a character-only payload (no sessions, only linkage + identity).
function addon:BuildCharacterExportPayload()
    return {
        format        = CHAR_EXPORT_FORMAT,
        formatVersion = CHAR_EXPORT_VERSION,
        schemaVersion = WhateverRoyaleDB.schemaVersion,
        addonVersion  = addon.version,
        exportedAt    = time(),
        exportedBy    = self:GetCurrentCharacterId(),
        characters    = CollectExportCharacters(nil),
    }
end

-- Serialise, compress and encode a session payload (prefix WR1!).
-- Returns (string, nil) on success, (string, "warn_size") if large, (nil, err) on failure.
function addon:EncodeExportString(payload)
    return EncodePayload(payload, EXPORT_PREFIX)
end

-- Serialise, compress and encode a character payload (prefix WRC1!).
function addon:EncodeCharacterExportString(payload)
    return EncodePayload(payload, CHAR_EXPORT_PREFIX)
end

-- Stamp sessions as exported (sets session.exportedAt).
function addon:MarkSessionsExported(sessionIds)
    local ts = time()
    for _, sid in ipairs(sessionIds) do
        local s = WhateverRoyaleDB.sessions[sid]
        if s then s.exportedAt = ts end
    end
end

-- Returns a rough pre-compression size estimate in bytes.
-- Used for the UI preview — not a guarantee.
function addon:EstimateExportSize(sessionIds)
    if #sessionIds == 0 then return 0 end
    -- ~1.5 KB per session after compression + EncodeForPrint overhead
    return #sessionIds * 1500
end

function addon:GetExportWarnThreshold()
    return WARN_BYTES
end
