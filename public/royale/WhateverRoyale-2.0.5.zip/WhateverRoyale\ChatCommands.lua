--[[
    WhateverRoyale - ChatCommands.lua
    Chat command handling and routing
]]

local addonName, addon = ...

-- Main help command
local function showHelp()
    print(addon.config.colors.primary .. "[WhateverRoyale Help]" .. addon.config.colors.reset)
    print(addon.config.colors.gold .. "/wr open" .. addon.config.colors.reset .. " - Open the main UI")
    print(addon.config.colors.gold .. "/wr session" .. addon.config.colors.reset .. " - Create a new Simple Dice session")
    print(addon.config.colors.gold .. "/wr stats" .. addon.config.colors.reset .. " - Open statistics leaderboard")
    print(addon.config.colors.gold .. "/wr mainalt" .. addon.config.colors.reset .. " - Manage main/alt characters")
    print(addon.config.colors.gold .. "/wr postsession [N]" .. addon.config.colors.reset .. " - Post session Top/Flop N to chat (default: 5)")
    print(addon.config.colors.gold .. "/wr postlb [N]" .. addon.config.colors.reset .. " - Post overall leaderboard Top/Flop N to chat (default: 5)")
    print(addon.config.colors.gold .. "/wr debug on|off" .. addon.config.colors.reset .. " - Toggle debug mode (admin only)")
    print(addon.config.colors.gold .. "/wr help" .. addon.config.colors.reset .. " - Show this help")
end

-- Main command handler
local function handleCommand(msg)
    -- Clean up input
    msg = strtrim(msg or "")

    -- Split into command and arguments
    local args = {strsplit(" ", msg)}
    local cmd = string.lower(args[1] or "")

    -- Handle commands
    if cmd == "" or cmd == "help" then
        showHelp()

    elseif cmd == "open" then
        -- Toggle the main frame
        if addon.mainFrame then
            addon.mainFrame:ToggleVisibility()
        else
            addon:Error("Main frame not initialized yet. Try again in a moment.")
        end

    elseif cmd == "session" then
        -- Create a new Simple Dice session
        if not addon.CreateNewSession then
            addon:Error("Session system not initialized yet. Try again in a moment.")
            return
        end
        local sessionId = addon:CreateNewSession("simpleDice")
        if sessionId then
            addon:Success("Simple Dice session created! ID: " .. sessionId)
        else
            addon:Error("Failed to create session.")
        end

    elseif cmd == "stats" then
        -- Open statistics tab
        if addon.mainFrame then
            addon.mainFrame:Show()
            addon:SwitchTab("statistics")
        else
            addon:Error("Main frame not initialized yet. Try again in a moment.")
        end

    elseif cmd == "mainalt" then
        -- Open main/alt tab
        if addon.mainFrame then
            addon.mainFrame:Show()
            addon:SwitchTab("mainalt")
        else
            addon:Error("Main frame not initialized yet. Try again in a moment.")
        end

    elseif cmd == "postsession" then
        local n = math.max(1, math.min(tonumber(args[2]) or 5, 10))
        local sessionId = addon.chatMonitor and addon.chatMonitor.activeSessionId
        if not sessionId then
            addon:Error("Keine aktive Session.")
            return
        end
        addon:PostSessionStats(sessionId, n, "RAID")

    elseif cmd == "postlb" then
        local n = math.max(1, math.min(tonumber(args[2]) or 5, 10))
        addon:PostOverallLeaderboard(n, "RAID")

    elseif cmd == "debug" then
        -- Toggle debug mode (admin only)
        if not addon:IsAdmin() then
            addon:Error("You don't have permission to use this command.")
            return
        end

        local mode = string.lower(args[2] or "")
        if mode == "on" then
            WhateverRoyaleDB.settings.debugMode = true
            addon:Success("Debug mode enabled")
        elseif mode == "off" then
            WhateverRoyaleDB.settings.debugMode = false
            addon:Success("Debug mode disabled")
        else
            -- Toggle if no argument
            WhateverRoyaleDB.settings.debugMode = not WhateverRoyaleDB.settings.debugMode
            if WhateverRoyaleDB.settings.debugMode then
                addon:Success("Debug mode enabled")
            else
                addon:Success("Debug mode disabled")
            end
        end

    else
        addon:Error("Unknown command: " .. cmd)
        showHelp()
    end
end

-- Register slash commands
SLASH_WHATEVERROYALE1 = "/wr"
SLASH_WHATEVERROYALE2 = "/whateverroyale"
SLASH_WHATEVERROYALE3 = "/casino"

SlashCmdList["WHATEVERROYALE"] = handleCommand

-- /dice [amount] — quick-start a Simple Dice session
SLASH_WHATEVERROYALEDICE1 = "/dice"

SlashCmdList["WHATEVERROYALEDICE"] = function(msg)
    msg = strtrim(msg or "")

    local amount = 25000
    if msg ~= "" then
        local parsed = tonumber(msg)
        if not parsed or parsed < 1 then
            addon:Error("Usage: /dice [amount]  —  z.B. /dice 50000")
            return
        end
        amount = parsed
    end

    if not addon.CreateNewSession then
        addon:Error("Session-System noch nicht bereit. Kurz warten und nochmal versuchen.")
        return
    end

    local sessionId = addon:CreateNewSession("simpleDice", amount)
    if not sessionId then
        addon:Error("Session konnte nicht erstellt werden.")
        return
    end

    addon:StartSignUp(sessionId)
end
