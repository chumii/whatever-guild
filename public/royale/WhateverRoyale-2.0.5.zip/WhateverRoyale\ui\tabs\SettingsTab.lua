--[[
    WhateverRoyale - SettingsTab.lua
    Settings tab content using PixelUI
]]

local addonName, addon = ...
local PixelUI = addon.PixelUI

function addon:CreateSettingsTab(parent)
    -- Tab frame (fills parent content area)
    local tab = PixelUI.CreateFrame(parent, nil, 730, 460)
    tab:SetAllPoints(parent)
    tab:Hide()  -- Hidden by default, shown by tab switching

    -- Title
    local title = PixelUI.CreateText(tab, "Settings", "white")
    title:SetFontObject("GameFontNormalLarge")
    PixelUI.SetPoint(title, "TOPLEFT", 10, -10)

    -- ========================================================================
    -- General Settings Section (available to all users)
    -- ========================================================================

    local generalHeader = PixelUI.CreateText(tab, "General", "accent")
    PixelUI.SetPoint(generalHeader, "TOPLEFT", title, "BOTTOMLEFT", 0, -20)

    -- Hide Minimap Button Checkbox
    local hideMinimapCheckbox = PixelUI.CreateCheckButton(
        tab,
        "Hide Minimap Button",
        function(checked)
            if checked then
                addon:HideMinimapButton()
            else
                addon:ShowMinimapButton()
            end
        end
    )
    PixelUI.SetPoint(hideMinimapCheckbox, "TOPLEFT", generalHeader, "BOTTOMLEFT", 0, -10)

    -- Set initial state from SavedVariables
    local isHidden = addon:IsMinimapButtonHidden()
    hideMinimapCheckbox:SetChecked(isHidden)

    -- Store reference
    tab.hideMinimapCheckbox = hideMinimapCheckbox

    -- Error Message Mode Checkbox
    local errormsgCheckbox = PixelUI.CreateCheckButton(
        tab,
        "Enable Error Messages",
        function(checked)
            if WhateverRoyaleDB and WhateverRoyaleDB.settings then
                WhateverRoyaleDB.settings.errormsgMode = checked
            end

            if checked then
                addon:Success("Error Messages enabled")
            else
                addon:Info("Error Messages disabled")
            end
        end
    )
    PixelUI.SetPoint(errormsgCheckbox, "TOPLEFT", hideMinimapCheckbox, "BOTTOMLEFT", 0, -10)

    -- Set initial state from SavedVariables
    local defaultErrormsgMode = false
    if WhateverRoyaleDB and WhateverRoyaleDB.settings then
        defaultErrormsgMode = WhateverRoyaleDB.settings.errormsgMode
    end
    errormsgCheckbox:SetChecked(defaultErrormsgMode)

    -- Store reference
    tab.errormsgCheckbox = errormsgCheckbox

    -- Warning Message Mode Checkbox
    local warningmsgCheckbox = PixelUI.CreateCheckButton(
        tab,
        "Enable Warning Messages",
        function(checked)
            if WhateverRoyaleDB and WhateverRoyaleDB.settings then
                WhateverRoyaleDB.settings.warningmsgMode = checked
            end

            if checked then
                addon:Success("Warning Messages enabled")
            else
                addon:Info("Warning Messages disabled")
            end
        end
    )
    PixelUI.SetPoint(warningmsgCheckbox, "TOPLEFT", errormsgCheckbox, "BOTTOMLEFT", 0, -10)

    -- Set initial state from SavedVariables
    local defaultWarningmsgMode = false
    if WhateverRoyaleDB and WhateverRoyaleDB.settings then
        defaultWarningmsgMode = WhateverRoyaleDB.settings.warningmsgMode
    end
    warningmsgCheckbox:SetChecked(defaultwarningmsgMode)

    -- Store reference
    tab.warningmsgCheckbox = warningmsgCheckbox

    -- Success Message Mode Checkbox
    local successmsgCheckbox = PixelUI.CreateCheckButton(
        tab,
        "Enable Success Messages",
        function(checked)
            if WhateverRoyaleDB and WhateverRoyaleDB.settings then
                WhateverRoyaleDB.settings.successmsgMode = checked
            end

            if checked then
                addon:Success("Success Messages enabled")
            else
                addon:Info("Success Messages disabled")
            end
        end
    )
    PixelUI.SetPoint(successmsgCheckbox, "TOPLEFT", warningmsgCheckbox, "BOTTOMLEFT", 0, -10)

    -- Set initial state from SavedVariables
    local defaultsuccessmsgMode = false
    if WhateverRoyaleDB and WhateverRoyaleDB.settings then
        defaultsuccessmsgMode = WhateverRoyaleDB.settings.successmsgMode
    end
    successmsgCheckbox:SetChecked(defaultsuccessmsgMode)

    -- Store reference
    tab.successmsgCheckbox = successmsgCheckbox

    -- Info Message Mode Checkbox
    local infomsgCheckbox = PixelUI.CreateCheckButton(
        tab,
        "Enable Info Messages",
        function(checked)
            if WhateverRoyaleDB and WhateverRoyaleDB.settings then
                WhateverRoyaleDB.settings.infomsgMode = checked
            end

            if checked then
                addon:Info("Info Messages enabled")
            else
                addon:Info("Info Messages disabled")
            end
        end
    )
    PixelUI.SetPoint(infomsgCheckbox, "TOPLEFT", successmsgCheckbox, "BOTTOMLEFT", 0, -10)

    -- Set initial state from SavedVariables
    local defaultinfomsgMode = false
    if WhateverRoyaleDB and WhateverRoyaleDB.settings then
        defaultinfomsgMode = WhateverRoyaleDB.settings.infomsgMode
    end
    infomsgCheckbox:SetChecked(defaultinfomsgMode)

    -- Store reference
    tab.infomsgCheckbox = infomsgCheckbox

    -- Auto-Share Checkbox
    local autoShareCheckbox = PixelUI.CreateCheckButton(
        tab,
        "Session-Daten automatisch mit Gruppe teilen",
        function(checked)
            if WhateverRoyaleDB and WhateverRoyaleDB.settings then
                WhateverRoyaleDB.settings.autoShareSessions = checked
            end
        end
    )
    PixelUI.SetPoint(autoShareCheckbox, "TOPLEFT", infomsgCheckbox, "BOTTOMLEFT", 0, -10)

    local defaultAutoShare = true
    if WhateverRoyaleDB and WhateverRoyaleDB.settings and
       WhateverRoyaleDB.settings.autoShareSessions ~= nil then
        defaultAutoShare = WhateverRoyaleDB.settings.autoShareSessions
    end
    autoShareCheckbox:SetChecked(defaultAutoShare)

    tab.autoShareCheckbox = autoShareCheckbox

    -- Track last element for positioning
    local lastElement = autoShareCheckbox

    

    -- ========================================================================
    -- Admin Settings Section (only for admins)
    -- ========================================================================

    -- Check if current character is admin
    local isAdmin = addon:IsAdmin()

    if isAdmin then
        -- Admin Header
        local adminHeader = PixelUI.CreateText(tab, "Admin Settings", "accent")
        PixelUI.SetPoint(adminHeader, "TOPLEFT", lastElement, "BOTTOMLEFT", 0, -25)

        -- Debug Mode Checkbox
        local debugCheckbox = PixelUI.CreateCheckButton(
            tab,
            "Enable Debug Mode",
            function(checked)
                if WhateverRoyaleDB and WhateverRoyaleDB.settings then
                    WhateverRoyaleDB.settings.debugMode = checked
                end

                if checked then
                    addon:Success("Debug mode enabled")
                else
                    addon:Info("Debug mode disabled")
                end
            end
        )
        PixelUI.SetPoint(debugCheckbox, "TOPLEFT", adminHeader, "BOTTOMLEFT", 0, -10)

        -- Set initial state from SavedVariables
        local defaultDebugMode = false
        if WhateverRoyaleDB and WhateverRoyaleDB.settings then
            defaultDebugMode = WhateverRoyaleDB.settings.debugMode
        end
        debugCheckbox:SetChecked(defaultDebugMode)

        -- Store reference
        tab.debugCheckbox = debugCheckbox

        -- Admin Tools Section
        local toolsHeader = PixelUI.CreateText(tab, "Admin Tools", "accent")
        PixelUI.SetPoint(toolsHeader, "TOPLEFT", debugCheckbox, "BOTTOMLEFT", 0, -25)

        -- Test Addon Communication Button
        local testMsgBtn = PixelUI.CreateButton(tab, "Send Test Message", "secondary", 150, 24)
        PixelUI.SetPoint(testMsgBtn, "TOPLEFT", toolsHeader, "BOTTOMLEFT", 0, -10)
        testMsgBtn:SetOnClick(function()
            local success = addon:SendAddonMessage("TEST", "Hello from WhateverRoyale host!")
            if success then
                addon:Success("Test message sent to party channel")
            else
                addon:Warning("Failed to send message - are you in a party?")
            end
        end)
    end

    -- Register tab
    addon.tabs = addon.tabs or {}
    addon.tabs.settings = tab

    return tab
end
