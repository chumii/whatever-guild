--[[
    WhateverRoyale - MinimapButton.lua
    Minimap button using LibDBIcon-1.0
]]

local addonName, addon = ...

local LDB = LibStub("LibDataBroker-1.1"):NewDataObject("WhateverRoyale", {
    type = "launcher",
    text = "WhateverRoyale",
    icon = "Interface\\Icons\\Inv_10_fishing_dragonislescoins_gold",
    OnClick = function(self, mouseButton)
        if mouseButton == "LeftButton" and addon.mainFrame then
            addon.mainFrame:ToggleVisibility()
        end
    end,
    OnTooltipShow = function(tooltip)
        tooltip:SetText("|cFF9482C9WhateverRoyale|r")
        tooltip:AddLine("Left-Click: Open/Close", 0.8, 0.8, 0.8)
        tooltip:AddLine("Drag: Move button", 0.6, 0.6, 0.6)
    end,
})

local icon = LibStub("LibDBIcon-1.0")

-- Register the icon once the SavedVariables DB is available
local initFrame = CreateFrame("Frame")
initFrame:RegisterEvent("PLAYER_LOGIN")
initFrame:SetScript("OnEvent", function()
    WhateverRoyaleDB.minimapButton = WhateverRoyaleDB.minimapButton or {}
    icon:Register("WhateverRoyale", LDB, WhateverRoyaleDB.minimapButton)
end)

-- Public API (mirrors the old interface)
function addon:ShowMinimapButton()
    icon:Show("WhateverRoyale")
    if WhateverRoyaleDB and WhateverRoyaleDB.minimapButton then
        WhateverRoyaleDB.minimapButton.hide = false
    end
end

function addon:HideMinimapButton()
    icon:Hide("WhateverRoyale")
    if WhateverRoyaleDB and WhateverRoyaleDB.minimapButton then
        WhateverRoyaleDB.minimapButton.hide = true
    end
end

function addon:IsMinimapButtonHidden()
    return WhateverRoyaleDB and WhateverRoyaleDB.minimapButton and
           WhateverRoyaleDB.minimapButton.hide
end
