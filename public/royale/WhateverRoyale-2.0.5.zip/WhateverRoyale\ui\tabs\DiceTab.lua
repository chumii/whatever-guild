--[[
    WhateverRoyale - DiceTab.lua
    Simple Dice tab content using PixelUI
]]

local addonName, addon = ...
local PixelUI = addon.PixelUI

function addon:CreateDiceTab(parent)
    -- Tab frame (fills parent content area)
    local tab = PixelUI.CreateFrame(parent, nil, 730, 460)
    tab:SetAllPoints(parent)
    tab:Hide()  -- Hidden by default, shown by tab switching

    -- Title
    local title = PixelUI.CreateText(tab, "Simple Dice", "white")
    title:SetFontObject("GameFontNormalLarge")
    PixelUI.SetPoint(title, "TOPLEFT", 10, -10)

    -- Description
    local description = PixelUI.CreateText(
        tab,
        "All players roll for a set amount of gold. The highest roll wins the difference between high and low from the lowest roller.",
        "gray"
    )
    PixelUI.SetPoint(description, "TOPLEFT", title, "BOTTOMLEFT", 0, -10)
    description:SetWidth(710)
    description:SetJustifyH("LEFT")
    description:SetWordWrap(true)

    -- Roll Amount
    local rollAmountLabel = PixelUI.CreateText(tab, "Roll Amount:", "white")
    PixelUI.SetPoint(rollAmountLabel, "TOPLEFT", description, "BOTTOMLEFT", 0, -20)
    rollAmountLabel:SetWidth(100)
    rollAmountLabel:SetJustifyH("LEFT")

    local rollAmountInput = PixelUI.CreateEditBox(tab, nil, 100, 20, "number")
    PixelUI.SetPoint(rollAmountInput, "TOPLEFT", rollAmountLabel, "TOPRIGHT", 10, 0)

    -- Set initial value
    local defaultAmount = 25000
    if WhateverRoyaleDB and WhateverRoyaleDB.gameSettings and
       WhateverRoyaleDB.gameSettings.simpleDice then
        defaultAmount = WhateverRoyaleDB.gameSettings.simpleDice.rollAmount
    end
    rollAmountInput:SetText(tostring(defaultAmount))

    -- Change handler
    rollAmountInput:SetOnTextChanged(function(value)
        local amount = tonumber(value)
        if amount and amount > 0 and WhateverRoyaleDB and
           WhateverRoyaleDB.gameSettings and
           WhateverRoyaleDB.gameSettings.simpleDice then
            WhateverRoyaleDB.gameSettings.simpleDice.rollAmount = amount
        end
    end)

    local rollAmountGold = PixelUI.CreateText(tab, "gold", "gray")
    PixelUI.SetPoint(rollAmountGold, "LEFT", rollAmountInput, "RIGHT", 5, 0)

    -- Channel Dropdown
    local channelLabel = PixelUI.CreateText(tab, "Chat Channel:", "white")
    PixelUI.SetPoint(channelLabel, "TOPLEFT", rollAmountLabel, "BOTTOMLEFT", 0, -20)
    channelLabel:SetWidth(100)
    channelLabel:SetJustifyH("LEFT")

    local channelDropdown = PixelUI.CreateDropdown(tab, 150)
    PixelUI.SetPoint(channelDropdown, "TOPLEFT", channelLabel, "TOPRIGHT", 10, -2)

    channelDropdown:SetItems({
        {text = "PARTY", value = "PARTY"},
        {text = "RAID", value = "RAID"},
        {text = "INSTANCE", value = "INSTANCE"},
        {text = "GUILD", value = "GUILD"},
    })

    -- Set initial selection
    local currentChannel = "RAID"
    if WhateverRoyaleDB and WhateverRoyaleDB.settings then
        currentChannel = WhateverRoyaleDB.settings.defaultChannel
    end
    channelDropdown:SetSelected(currentChannel)

    -- Change handler
    channelDropdown:SetOnSelect(function(value)
        if WhateverRoyaleDB and WhateverRoyaleDB.settings then
            WhateverRoyaleDB.settings.defaultChannel = value
        end
    end)

    -- Create Session Button
    local createButton = PixelUI.CreateButton(tab, "Create New Session", "primary", 150, 28)
    PixelUI.SetPoint(createButton, "TOPLEFT", channelLabel, "BOTTOMLEFT", 0, -30)

    createButton:SetOnClick(function()
        local sessionId = addon:CreateNewSession("simpleDice")
        if sessionId then
            addon:Success("Session created! ID: " .. sessionId)
        end
    end)

    -- Active Sessions Header
    local sessionsHeader = PixelUI.CreateText(tab, "Active Sessions", "accent")
    PixelUI.SetPoint(sessionsHeader, "TOPLEFT", createButton, "BOTTOMLEFT", 0, -30)

    -- Active Sessions Text
    local sessionsText = PixelUI.CreateText(
        tab,
        "No active sessions.\nCreate a new session to get started!",
        "gray"
    )
    PixelUI.SetPoint(sessionsText, "TOPLEFT", sessionsHeader, "BOTTOMLEFT", 0, -10)
    sessionsText:SetJustifyH("LEFT")
    sessionsText:SetJustifyV("TOP")

    -- Store reference for updating
    tab.sessionsText = sessionsText

    -- Register tab
    addon.tabs = addon.tabs or {}
    addon.tabs.dice = tab

    return tab
end
