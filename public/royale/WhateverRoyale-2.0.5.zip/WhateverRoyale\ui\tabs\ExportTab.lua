--[[
    WhateverRoyale - ExportTab.lua
    Session export UI. Shows sessions grouped by date, lets the host select
    sessions and produces a WR1! import string for the Vercel/Supabase website.
]]

local addonName, addon = ...
local PixelUI = addon.PixelUI

local TAB_PADDING     = 12
local SECTION_SPACING = 16
local ELEMENT_SPACING = 8
local HEADER_HEIGHT   = 28
local ROW_HEIGHT      = 22
local SCROLL_WIDTH    = 706
local SCROLL_HEIGHT   = 320

-- ============================================================================
-- Helpers
-- ============================================================================

local WEEKDAYS = {"So", "Mo", "Di", "Mi", "Do", "Fr", "Sa"}

local function DateKey(timestamp)
    return date("%Y-%m-%d", timestamp)
end

local function FriendlyDate(dateKey)
    local y, m, d = dateKey:match("(%d+)-(%d+)-(%d+)")
    if not y then return dateKey end
    local t  = time({year = tonumber(y), month = tonumber(m), day = tonumber(d)})
    local wd = WEEKDAYS[tonumber(date("%w", t)) + 1] or "?"
    return string.format("%s %s.%s.%s", wd, d, m, y)
end

local function GameLabel(gameType)
    if gameType == "simpleDice" then return "Dice" end
    if gameType == "deathRoll"  then return "DR"   end
    return gameType or "?"
end

local function ParticipantCount(session)
    local n = 0
    for _ in pairs(session.participants or {}) do n = n + 1 end
    return n
end

local function FormatKB(bytes)
    if bytes < 1024 then
        return bytes .. " B"
    end
    return string.format("%.1f KB", bytes / 1024)
end

-- Returns { [dateKey] = {entries}, ... } and a sorted list of date keys (desc).
local function GroupSessions(filterMode)
    local groups = {}
    local order  = {}

    for sid, session in pairs(WhateverRoyaleDB.sessions or {}) do
        if session.status == "completed" or session.status == "abandoned" then
            local include = true
            if filterMode == "new" then
                include = not session.exportedAt
            elseif filterMode == "exported" then
                include = session.exportedAt ~= nil
            end

            if include then
                local dk = DateKey(session.startTime)
                if not groups[dk] then
                    groups[dk] = {}
                    order[#order + 1] = dk
                end
                groups[dk][#groups[dk] + 1] = {id = sid, session = session}
            end
        end
    end

    table.sort(order, function(a, b) return a > b end)

    for _, dk in ipairs(order) do
        table.sort(groups[dk], function(a, b)
            return (a.session.startTime or 0) > (b.session.startTime or 0)
        end)
    end

    return groups, order
end

-- ============================================================================
-- Row / Header widget factories
-- ============================================================================

local function CreateDayHeader(parent)
    local row = CreateFrame("Button", nil, parent, "BackdropTemplate")
    row:SetHeight(HEADER_HEIGHT)
    row:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    row:SetBackdropColor(0.12, 0.12, 0.15, 1)
    row:SetBackdropBorderColor(0.22, 0.22, 0.25, 1)

    local arrow = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    arrow:SetPoint("LEFT", 8, 0)
    arrow:SetTextColor(0.60, 0.55, 0.75, 1)
    row.arrow = arrow

    local label = row:CreateFontString(nil, "OVERLAY", "GameFontNormal")
    label:SetPoint("LEFT", arrow, "RIGHT", 4, 0)
    label:SetTextColor(0.90, 0.88, 0.95, 1)
    row.label = label

    local count = row:CreateFontString(nil, "OVERLAY", "GameFontNormalSmall")
    count:SetPoint("LEFT", label, "RIGHT", 10, 0)
    count:SetTextColor(0.55, 0.55, 0.55, 1)
    row.count = count

    row:SetScript("OnEnter", function(self)
        self:SetBackdropColor(0.18, 0.17, 0.22, 1)
    end)
    row:SetScript("OnLeave", function(self)
        self:SetBackdropColor(0.12, 0.12, 0.15, 1)
    end)

    return row
end

local function CreateSessionRow(parent)
    local row = CreateFrame("Button", nil, parent, "BackdropTemplate")
    row:SetHeight(ROW_HEIGHT)
    row:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    row:SetBackdropColor(0, 0, 0, 0)
    row:SetBackdropBorderColor(0, 0, 0, 0)

    -- Tiny checkbox
    local box = CreateFrame("Frame", nil, row, "BackdropTemplate")
    box:SetSize(13, 13)
    box:SetPoint("LEFT", 22, 0)
    box:SetBackdrop({
        bgFile   = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Buttons\\WHITE8x8",
        edgeSize = 1,
    })
    box:SetBackdropColor(0.13, 0.13, 0.16, 1)
    box:SetBackdropBorderColor(0.35, 0.35, 0.40, 1)

    local checkMark = box:CreateTexture(nil, "OVERLAY")
    checkMark:SetTexture("Interface\\Buttons\\WHITE8x8")
    checkMark:SetPoint("TOPLEFT",     3, -3)
    checkMark:SetPoint("BOTTOMRIGHT", -3, 3)
    checkMark:SetVertexColor(0.60, 0.45, 0.85, 1)
    checkMark:Hide()
    row.checkMark = checkMark
    row.box       = box

    -- Session info label
    local info = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    info:SetPoint("LEFT", box, "RIGHT", 7, 0)
    info:SetTextColor(0.80, 0.78, 0.82, 1)
    row.info = info

    -- Exported indicator (right side)
    local exported = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    exported:SetPoint("RIGHT", -8, 0)
    exported:SetTextColor(0.27, 0.85, 0.45, 1)
    exported:SetText("exportiert")
    exported:Hide()
    row.exported = exported

    row:SetScript("OnEnter", function(self)
        if not self._checked then
            self:SetBackdropColor(0.10, 0.10, 0.13, 0.6)
        end
    end)
    row:SetScript("OnLeave", function(self)
        if not self._checked then
            self:SetBackdropColor(0, 0, 0, 0)
        end
    end)

    function row:SetChecked(checked)
        self._checked = checked
        if checked then
            checkMark:Show()
            self:SetBackdropColor(0.14, 0.11, 0.20, 0.8)
        else
            checkMark:Hide()
            self:SetBackdropColor(0, 0, 0, 0)
        end
    end

    return row
end

-- ============================================================================
-- Export string popup
-- ============================================================================

function addon:ShowExportStringPopup(exportString)
    if not addon._exportPopup then
        local popup = PixelUI.CreateMainFrame(
            UIParent, "WRExportStringPopup", "Export String", 620, 300
        )
        PixelUI.SetPoint(popup, "CENTER")
        popup:SetFrameStrata("DIALOG")

        local hint = PixelUI.CreateText(
            popup.content,
            "Strg+A zum Alles auswählen, dann Strg+C zum Kopieren.",
            "gray"
        )
        PixelUI.SetPoint(hint, "TOPLEFT", 10, -10)

        local editBox = PixelUI.CreateEditBox(
            popup.content, "", 596, 220, "multiline"
        )
        PixelUI.SetPoint(editBox, "TOPLEFT", hint, "BOTTOMLEFT", 0, -8)

        addon._exportPopup       = popup
        addon._exportPopupEditBox = editBox
    end

    local eb = addon._exportPopupEditBox
    eb:SetText(exportString)
    -- select all so Ctrl+C works immediately
    C_Timer.After(0.05, function()
        if eb.editBox then
            eb.editBox:SetFocus()
            eb.editBox:HighlightText()
        end
    end)
    addon._exportPopup:Show()
end

-- ============================================================================
-- List refresh
-- ============================================================================

local function UpdateStatusBar(tab)
    local count = 0
    for _ in pairs(tab._selected) do count = count + 1 end

    local ids = {}
    for sid in pairs(tab._selected) do ids[#ids + 1] = sid end
    local estBytes = addon:EstimateExportSize(ids)

    if count == 0 then
        tab._statusText:SetText("|cFF888888Keine Sessions ausgewählt|r")
        tab._exportBtn:SetEnabled(false)
        tab._deleteBtn:SetEnabled(false)
    else
        tab._statusText:SetText(string.format(
            "|cFFCCCCCC%d Session%s ausgewählt|r  ·  |cFF888888~%s|r",
            count, count == 1 and "" or "s", FormatKB(estBytes)
        ))
        tab._exportBtn:SetEnabled(true)
        tab._deleteBtn:SetEnabled(true)
    end
end

function addon:RefreshExportList(tab)
    if not tab or not tab.exportScroll then return end

    local scrollChild = tab.exportScroll.scrollContent

    -- Hide all pooled widgets
    for _, w in ipairs(tab._headerPool) do w:Hide() end
    for _, w in ipairs(tab._rowPool)    do w:Hide() end

    local groups, order = GroupSessions(tab._filterMode)
    local headerIdx = 0
    local rowIdx    = 0
    local yOffset   = 0

    for _, dk in ipairs(order) do
        local entries  = groups[dk]
        local expanded = tab._expanded[dk] ~= false  -- default: expanded

        -- Day header
        headerIdx = headerIdx + 1
        local hdr = tab._headerPool[headerIdx]
        if not hdr then
            hdr = CreateDayHeader(scrollChild)
            tab._headerPool[headerIdx] = hdr
        end

        hdr:ClearAllPoints()
        hdr:SetPoint("TOPLEFT",  scrollChild, "TOPLEFT",  0, -yOffset)
        hdr:SetPoint("TOPRIGHT", scrollChild, "TOPRIGHT", 0, -yOffset)
        hdr:SetHeight(HEADER_HEIGHT)

        hdr.arrow:SetText(expanded and "[-]" or "[+]")
        hdr.label:SetText(FriendlyDate(dk))
        hdr.count:SetText("(" .. #entries .. ")")

        local capturedDk = dk
        hdr:SetScript("OnClick", function()
            tab._expanded[capturedDk] = not (tab._expanded[capturedDk] ~= false)
            addon:RefreshExportList(tab)
        end)
        hdr:Show()

        yOffset = yOffset + HEADER_HEIGHT + 1

        if expanded then
            for _, entry in ipairs(entries) do
                rowIdx = rowIdx + 1
                local row = tab._rowPool[rowIdx]
                if not row then
                    row = CreateSessionRow(scrollChild)
                    tab._rowPool[rowIdx] = row
                end

                row:ClearAllPoints()
                row:SetPoint("TOPLEFT",  scrollChild, "TOPLEFT",  0, -yOffset)
                row:SetPoint("TOPRIGHT", scrollChild, "TOPRIGHT", 0, -yOffset)
                row:SetHeight(ROW_HEIGHT)

                local sid     = entry.id
                local session = entry.session
                local timeStr = date("%H:%M", session.startTime)
                local players = ParticipantCount(session)
                local rounds  = #(session.rounds or {})
                local checked = tab._selected[sid] or false

                row.info:SetText(string.format(
                    "%s   %s   %dP   %dR",
                    timeStr, GameLabel(session.gameType), players, rounds
                ))

                if session.exportedAt then
                    row.exported:Show()
                else
                    row.exported:Hide()
                end

                row:SetChecked(checked)

                local capturedSid = sid
                row:SetScript("OnClick", function(self)
                    local nowChecked = not (tab._selected[capturedSid] or false)
                    if nowChecked then
                        tab._selected[capturedSid] = true
                    else
                        tab._selected[capturedSid] = nil
                    end
                    self:SetChecked(nowChecked)
                    UpdateStatusBar(tab)
                end)

                row:Show()
                yOffset = yOffset + ROW_HEIGHT
            end
        end
    end

    -- Empty state
    if #order == 0 then
        if not tab._emptyText then
            tab._emptyText = PixelUI.CreateText(
                scrollChild,
                "Keine abgeschlossenen Sessions vorhanden.",
                "gray"
            )
            PixelUI.SetPoint(tab._emptyText, "TOPLEFT", 12, -16)
        end
        tab._emptyText:Show()
    else
        if tab._emptyText then tab._emptyText:Hide() end
    end

    scrollChild:SetHeight(math.max(1, yOffset))
    if tab.exportScroll._updateThumb then
        tab.exportScroll._updateThumb()
    end

    UpdateStatusBar(tab)
end

-- ============================================================================
-- Delete confirmation popup
-- ============================================================================

StaticPopupDialogs["WR_CONFIRM_DELETE_SESSIONS"] = {
    text = "Wirklich %d Session(s) loeschen?\nAlle Charakter-Statistiken werden neu berechnet.",
    button1 = "Loeschen",
    button2 = "Abbrechen",
    OnAccept = function()
        if not addon._pendingDeleteIds then return end
        local n = #addon._pendingDeleteIds
        addon:DeleteSessions(addon._pendingDeleteIds)
        addon._pendingDeleteTab._selected = {}
        addon:RefreshExportList(addon._pendingDeleteTab)
        if addon.tabs and addon.tabs.statistics then
            addon:RefreshLeaderboard(addon.tabs.statistics)
        end
        addon:Success(string.format("%d Session(s) geloescht. Statistiken aktualisiert.", n))
        addon._pendingDeleteIds = nil
        addon._pendingDeleteTab = nil
    end,
    OnCancel = function()
        addon._pendingDeleteIds = nil
        addon._pendingDeleteTab = nil
    end,
    timeout     = 0,
    whileDead   = true,
    hideOnEscape = true,
}

-- ============================================================================
-- Tab creation
-- ============================================================================

function addon:CreateExportTab(parent)
    local tab = PixelUI.CreateFrame(parent, nil, 730, 460)
    tab:SetAllPoints(parent)
    tab:Hide()

    -- State
    tab._selected   = {}    -- { [sessionId] = true }
    tab._expanded   = {}    -- { [dateKey]   = bool  }   nil = expanded
    tab._filterMode = "all" -- "all" | "new" | "exported"
    tab._headerPool = {}
    tab._rowPool    = {}

    -- Title
    local title = PixelUI.CreateText(tab, "Session Export", "white")
    title:SetFontObject("GameFontNormalLarge")
    PixelUI.SetPoint(title, "TOPLEFT", TAB_PADDING, -TAB_PADDING)

    -- Filter row
    local filterLabel = PixelUI.CreateText(tab, "Anzeigen:", "text")
    PixelUI.SetPoint(filterLabel, "TOPLEFT", title, "BOTTOMLEFT", 0, -SECTION_SPACING)
    filterLabel:SetWidth(70)
    filterLabel:SetJustifyH("LEFT")

    local filterDropdown = PixelUI.CreateDropdown(tab, 170)
    PixelUI.SetPoint(filterDropdown, "LEFT", filterLabel, "RIGHT", ELEMENT_SPACING, 0)

    filterDropdown:SetItems({
        {text = "Alle Sessions",       value = "all"},
        {text = "Nur neue (nicht exportiert)", value = "new"},
        {text = "Schon exportiert",    value = "exported"},
    })
    filterDropdown:SetSelected("all")
    filterDropdown:SetOnSelect(function(value)
        tab._filterMode = value
        tab._selected   = {}
        addon:RefreshExportList(tab)
    end)

    -- "Auswahl aufheben" helper button
    local clearBtn = PixelUI.CreateButton(tab, "Auswahl aufheben", "secondary", 140, 22)
    PixelUI.SetPoint(clearBtn, "LEFT", filterDropdown, "RIGHT", ELEMENT_SPACING * 2, 0)
    clearBtn:SetOnClick(function()
        tab._selected = {}
        addon:RefreshExportList(tab)
    end)

    -- "Alle neuen auswählen" — selects every not-yet-exported session
    local selectNewBtn = PixelUI.CreateButton(tab, "Neue auswählen", "secondary", 130, 22)
    PixelUI.SetPoint(selectNewBtn, "LEFT", clearBtn, "RIGHT", ELEMENT_SPACING, 0)
    selectNewBtn:SetOnClick(function()
        for sid, session in pairs(WhateverRoyaleDB.sessions or {}) do
            if (session.status == "completed" or session.status == "abandoned")
                and not session.exportedAt then
                tab._selected[sid] = true
            end
        end
        addon:RefreshExportList(tab)
    end)

    -- Separate character-only export button (right side of filter row)
    local charExportBtn = PixelUI.CreateButton(tab, "Charaktere exportieren", "secondary", 160, 22)
    PixelUI.SetPoint(charExportBtn, "LEFT", selectNewBtn, "RIGHT", ELEMENT_SPACING * 2, 0)
    charExportBtn:SetOnClick(function()
        local payload = addon:BuildCharacterExportPayload()
        local exportStr, warn = addon:EncodeCharacterExportString(payload)

        if not exportStr then
            addon:Error("Charakter-Export fehlgeschlagen: " .. (warn or "unbekannter Fehler"))
            return
        end

        if warn == "warn_size" then
            print(string.format(
                "|cFF9482C9[WhateverRoyale]|r Charakter-Export-String ist groß (%s).",
                FormatKB(#exportStr)
            ))
        end

        addon:ShowExportStringPopup(exportStr)
    end)

    -- Section header
    local sectionHeader = PixelUI.CreateText(tab, "Sessions", "accent")
    PixelUI.SetPoint(sectionHeader, "TOPLEFT", filterLabel, "BOTTOMLEFT", 0, -SECTION_SPACING)

    local refreshBtn = PixelUI.CreateButton(tab, "Aktualisieren", "secondary", 120, 22)
    PixelUI.SetPoint(refreshBtn, "LEFT", sectionHeader, "RIGHT", ELEMENT_SPACING * 2, 0)
    refreshBtn:SetOnClick(function()
        addon:RefreshExportList(tab)
    end)

    -- Scroll frame
    local scrollContainer = PixelUI.CreateScrollFrame(tab, "WRExportScroll", SCROLL_WIDTH, SCROLL_HEIGHT)
    PixelUI.SetPoint(scrollContainer, "TOPLEFT", sectionHeader, "BOTTOMLEFT", 0, -ELEMENT_SPACING)
    tab.exportScroll = scrollContainer

    -- Status bar (below scroll)
    local statusText = PixelUI.CreateText(tab, "Keine Sessions ausgewählt", "gray")
    PixelUI.SetPoint(statusText, "TOPLEFT", scrollContainer, "BOTTOMLEFT", 0, -ELEMENT_SPACING)
    tab._statusText = statusText

    -- Export button (right-aligned, same row as status)
    local exportBtn = PixelUI.CreateButton(tab, "Auswahl exportieren", "primary", 160, 24)
    PixelUI.SetPoint(exportBtn, "TOPRIGHT", scrollContainer, "BOTTOMRIGHT", 0, -(ELEMENT_SPACING - 1))
    tab._exportBtn = exportBtn

    -- Delete button (left of export button)
    local deleteBtn = PixelUI.CreateButton(tab, "Ausgewaehlte loeschen", "danger", 165, 24)
    PixelUI.SetPoint(deleteBtn, "TOPRIGHT", exportBtn, "TOPLEFT", -ELEMENT_SPACING, 0)
    tab._deleteBtn = deleteBtn

    deleteBtn:SetEnabled(false)
    deleteBtn:SetOnClick(function()
        local ids = {}
        for sid in pairs(tab._selected) do ids[#ids + 1] = sid end
        if #ids == 0 then return end
        addon._pendingDeleteIds = ids
        addon._pendingDeleteTab = tab
        StaticPopup_Show("WR_CONFIRM_DELETE_SESSIONS", #ids)
    end)

    exportBtn:SetEnabled(false)
    exportBtn:SetOnClick(function()
        local ids = {}
        for sid in pairs(tab._selected) do ids[#ids + 1] = sid end

        if #ids == 0 then
            addon:Warning("Keine Sessions ausgewählt.")
            return
        end

        local payload = addon:BuildExportPayload(ids)
        local exportStr, warn = addon:EncodeExportString(payload)

        if not exportStr then
            addon:Error("Export fehlgeschlagen: " .. (warn or "unbekannter Fehler"))
            return
        end

        if warn == "warn_size" then
            print(string.format(
                "|cFF9482C9[WhateverRoyale]|r Export-String ist groß (%s). " ..
                "Weniger Sessions auswählen für kleinere Strings.",
                FormatKB(#exportStr)
            ))
        end

        addon:MarkSessionsExported(ids)
        tab._selected = {}
        addon:RefreshExportList(tab)

        addon:ShowExportStringPopup(exportStr)
    end)

    -- Initial population
    addon:RefreshExportList(tab)

    -- Register tab
    addon.tabs        = addon.tabs or {}
    addon.tabs.export = tab

    return tab
end
