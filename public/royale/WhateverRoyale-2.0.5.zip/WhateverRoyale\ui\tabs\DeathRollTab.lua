--[[
    WhateverRoyale - DeathRollTab.lua
    Death-Roll game tab content using PixelUI
]]

local addonName, addon = ...
local PixelUI = addon.PixelUI

function addon:CreateDeathRollTab(parent)
    -- Tab frame (fills parent content area)
    local tab = PixelUI.CreateFrame(parent, nil, 730, 460)
    tab:SetAllPoints(parent)
    tab:Hide()  -- Hidden by default, shown by tab switching

    -- Title
    local title = PixelUI.CreateText(tab, "Death-Roll", "white")
    title:SetFontObject("GameFontNormalLarge")
    PixelUI.SetPoint(title, "TOPLEFT", 10, -10)

    -- Description
    local description = PixelUI.CreateText(
        tab,
        "Two players compete by rolling decreasing amounts. The first to roll 1 loses and pays the wager amount to the winner.",
        "gray"
    )
    PixelUI.SetPoint(description, "TOPLEFT", title, "BOTTOMLEFT", 0, -10)
    description:SetWidth(710)
    description:SetJustifyH("LEFT")
    description:SetWordWrap(true)

    -- Start Amount
    local startAmountLabel = PixelUI.CreateText(tab, "Start Amount:", "white")
    PixelUI.SetPoint(startAmountLabel, "TOPLEFT", description, "BOTTOMLEFT", 0, -20)
    startAmountLabel:SetWidth(100)
    startAmountLabel:SetJustifyH("LEFT")

    local startAmountInput = PixelUI.CreateEditBox(tab, nil, 100, 20, "number")
    PixelUI.SetPoint(startAmountInput, "TOPLEFT", startAmountLabel, "TOPRIGHT", 10, 0)

    -- Set initial value
    local defaultAmount = 100000
    if WhateverRoyaleDB and WhateverRoyaleDB.gameSettings and
       WhateverRoyaleDB.gameSettings.deathRoll then
        defaultAmount = WhateverRoyaleDB.gameSettings.deathRoll.startAmount
    end
    startAmountInput:SetText(tostring(defaultAmount))

    -- Change handler
    startAmountInput:SetOnTextChanged(function(value)
        local amount = tonumber(value)
        if amount and amount > 0 and WhateverRoyaleDB and
           WhateverRoyaleDB.gameSettings and
           WhateverRoyaleDB.gameSettings.deathRoll then
            WhateverRoyaleDB.gameSettings.deathRoll.startAmount = amount
        end
    end)

    local startAmountGold = PixelUI.CreateText(tab, "gold", "gray")
    PixelUI.SetPoint(startAmountGold, "LEFT", startAmountInput, "RIGHT", 5, 0)

    -- Channel Dropdown
    local channelLabel = PixelUI.CreateText(tab, "Chat Channel:", "white")
    PixelUI.SetPoint(channelLabel, "TOPLEFT", startAmountLabel, "BOTTOMLEFT", 0, -20)
    channelLabel:SetWidth(100)
    channelLabel:SetJustifyH("LEFT")

    local channelDropdown = PixelUI.CreateDropdown(tab, 150)
    PixelUI.SetPoint(channelDropdown, "TOPLEFT", channelLabel, "TOPRIGHT", 10, -2)

    channelDropdown:SetItems({
        {text = "PARTY", value = "PARTY"},
        {text = "RAID", value = "RAID"},
        {text = "INSTANCE", value = "INSTANCE"},
        {text = "GUILD", value = "GUILD"},
    })

    -- Set initial selection
    local currentChannel = "RAID"
    if WhateverRoyaleDB and WhateverRoyaleDB.settings then
        currentChannel = WhateverRoyaleDB.settings.defaultChannel
    end
    channelDropdown:SetSelected(currentChannel)

    -- Change handler
    channelDropdown:SetOnSelect(function(value)
        if WhateverRoyaleDB and WhateverRoyaleDB.settings then
            WhateverRoyaleDB.settings.defaultChannel = value
        end
    end)

    -- Create Session Button
    local createButton = PixelUI.CreateButton(tab, "Create New Session", "primary", 150, 28)
    PixelUI.SetPoint(createButton, "TOPLEFT", channelLabel, "BOTTOMLEFT", 0, -30)

    createButton:SetOnClick(function()
        local sessionId = addon:CreateNewSession("deathRoll")
        if sessionId then
            addon:Success("Death-Roll session created! ID: " .. sessionId)
        end
    end)

    -- Active Sessions Header
    local sessionsHeader = PixelUI.CreateText(tab, "Active Sessions", "accent")
    PixelUI.SetPoint(sessionsHeader, "TOPLEFT", createButton, "BOTTOMLEFT", 0, -30)

    -- Active Sessions Text
    local sessionsText = PixelUI.CreateText(
        tab,
        "No active sessions.\nCreate a new session to get started!",
        "gray"
    )
    PixelUI.SetPoint(sessionsText, "TOPLEFT", sessionsHeader, "BOTTOMLEFT", 0, -10)
    sessionsText:SetJustifyH("LEFT")
    sessionsText:SetJustifyV("TOP")

    -- Store reference for updating
    tab.sessionsText = sessionsText

    -- Register tab
    addon.tabs = addon.tabs or {}
    addon.tabs.deathroll = tab

    return tab
end
