--[[
    WhateverRoyale - MainAltTab.lua
    Main/Alt character management using PixelUI

    Features:
    - List all known characters
    - Set character type (Unlinked, Main, Alt)
    - Link alts to mains
    - Save and refresh functionality
]]

local _, addon = ...
local PixelUI = addon.PixelUI

function addon:CreateMainAltTab(parent)
    -- Tab frame (fills parent content area)
    local tab = PixelUI.CreateFrame(parent, nil, 730, 610)
    tab:SetAllPoints(parent)
    tab:Hide()

    -- Title
    local title = PixelUI.CreateText(tab, "Main & Alt Characters", "white")
    title:SetFontObject("GameFontNormalLarge")
    PixelUI.SetPoint(title, "TOPLEFT", 10, -10)

    -- Description
    local description = PixelUI.CreateText(
        tab,
        "Link your alt characters to a main character. When 'Merge Mains & Alts' is enabled in Statistics, all linked characters' stats will be combined under the main character.",
        "gray"
    )
    PixelUI.SetPoint(description, "TOPLEFT", title, "BOTTOMLEFT", 0, -10)
    description:SetWidth(710)
    description:SetJustifyH("LEFT")
    description:SetWordWrap(true)

    -- Characters Header
    local charactersHeader = PixelUI.CreateText(tab, "Characters", "accent")
    PixelUI.SetPoint(charactersHeader, "TOPLEFT", description, "BOTTOMLEFT", 0, -20)

    -- Table Header Line
    local headerLine = PixelUI.CreateTexture(tab, nil, {0.3, 0.3, 0.3, 0.5})
    PixelUI.SetSize(headerLine, 710, 1)
    PixelUI.SetPoint(headerLine, "TOPLEFT", charactersHeader, "BOTTOMLEFT", 0, -5)

    -- Table Headers (aligned with row content)
    local headerName = PixelUI.CreateText(tab, "Character Name", "gray")
    PixelUI.SetPoint(headerName, "TOPLEFT", headerLine, "BOTTOMLEFT", 20, -8)
    headerName:SetWidth(200)
    headerName:SetJustifyH("LEFT")

    local headerType = PixelUI.CreateText(tab, "Type", "gray")
    PixelUI.SetPoint(headerType, "LEFT", headerName, "RIGHT", 10, 0)
    headerType:SetWidth(100)
    headerType:SetJustifyH("LEFT")

    local headerMain = PixelUI.CreateText(tab, "Linked Main", "gray")
    PixelUI.SetPoint(headerMain, "LEFT", headerType, "RIGHT", 10, 0)
    headerMain:SetWidth(180)
    headerMain:SetJustifyH("LEFT")

    -- Character list scroll frame
    local listScrollFrame = PixelUI.CreateScrollFrame(tab, "WR_CharacterListScroll", 710, 280)
    PixelUI.SetPoint(listScrollFrame, "TOPLEFT", headerName, "BOTTOMLEFT", -10, -5)

    tab.listScrollChild = listScrollFrame.scrollContent
    tab.listRows = {}

    -- Action Buttons
    local btnRefresh = PixelUI.CreateButton(tab, "Refresh", "accent", 120, 30)
    PixelUI.SetPoint(btnRefresh, "TOPLEFT", listScrollFrame, "BOTTOMLEFT", 0, -15)

    btnRefresh:SetOnClick(function()
        addon:RefreshCharacterList(tab)
        addon:Success("Character list refreshed")
    end)

    local btnSave = PixelUI.CreateButton(tab, "Save Changes", "green", 120, 30)
    PixelUI.SetPoint(btnSave, "LEFT", btnRefresh, "RIGHT", 10, 0)

    btnSave:SetOnClick(function()
        addon:SaveCharacterLinks(tab)
    end)

    -- Info/Tips Section
    local infoHeader = PixelUI.CreateText(tab, "Tips", "accent")
    PixelUI.SetPoint(infoHeader, "TOPLEFT", btnRefresh, "BOTTOMLEFT", 0, -20)

    local infoText = PixelUI.CreateText(
        tab,
        "• Set a character as 'Main' to mark it as your primary character\n" ..
        "• Set a character as 'Alt' and link it to a main to combine statistics\n" ..
        "• Changes are saved automatically when you modify the dropdowns\n" ..
        "• Only characters who have played at least one game will appear in this list",
        "gray"
    )
    PixelUI.SetPoint(infoText, "TOPLEFT", infoHeader, "BOTTOMLEFT", 0, -10)
    infoText:SetWidth(710)
    infoText:SetJustifyH("LEFT")
    infoText:SetSpacing(2)

    -- Initial population
    self:RefreshCharacterList(tab)

    -- Register tab
    addon.tabs = addon.tabs or {}
    addon.tabs.mainalt = tab

    return tab
end

-- Refresh the character list
function addon:RefreshCharacterList(tab)
    if not tab or not tab.listScrollChild then return end

    -- Clear existing rows
    for _, row in ipairs(tab.listRows) do
        row:Hide()
    end

    -- Get all characters
    local characters = {}

    -- Safety check: return early if database not initialized
    if not WhateverRoyaleDB or not WhateverRoyaleDB.characters then
        return
    end

    for characterId, character in pairs(WhateverRoyaleDB.characters) do
        table.insert(characters, character)
    end

    -- Sort by name
    table.sort(characters, function(a, b)
        return a.name < b.name
    end)

    -- Create/update rows
    for i, character in ipairs(characters) do
        local row = tab.listRows[i]
        if not row then
            row = self:CreateCharacterRow(tab.listScrollChild, i)
            tab.listRows[i] = row
        end

        -- Update row
        row.nameText:SetText(character.characterId)

        -- Update type dropdown
        self:UpdateTypeDropdown(row.typeDropdown, character)

        -- Update main dropdown
        self:UpdateMainDropdown(row.mainDropdown, character)

        row:Show()
    end

    -- Update scroll content height
    local contentHeight = math.max(1, #characters * 32)
    tab.listScrollChild:SetHeight(contentHeight)

    -- Show/hide "no data" message
    if #characters == 0 then
        if not tab.noDataText then
            tab.noDataText = PixelUI.CreateText(
                tab.listScrollChild,
                "No characters found.\nPlay a game to add characters to this list!",
                "gray"
            )
            PixelUI.SetPoint(tab.noDataText, "CENTER", tab.listScrollChild, "CENTER", 0, 0)
        end
        tab.noDataText:Show()
    else
        if tab.noDataText then
            tab.noDataText:Hide()
        end
    end
end

-- Create a character row
function addon:CreateCharacterRow(parent, index)
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(690, 30)
    row:SetPoint("TOPLEFT", parent, "TOPLEFT", 10, -(index - 1) * 32)

    -- Alternating background
    if index % 2 == 0 then
        local bg = row:CreateTexture(nil, "BACKGROUND")
        bg:SetColorTexture(0.1, 0.1, 0.1, 0.3)
        bg:SetAllPoints(row)
    end

    -- Character name
    row.nameText = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    row.nameText:SetPoint("LEFT", row, "LEFT", 10, 0)
    row.nameText:SetWidth(200)
    row.nameText:SetJustifyH("LEFT")

    -- Type dropdown (Unlinked/Main/Alt)
    row.typeDropdown = PixelUI.CreateDropdown(row, 100)
    row.typeDropdown:SetPoint("LEFT", row.nameText, "RIGHT", 10, 0)

    -- Main dropdown (for alts)
    row.mainDropdown = PixelUI.CreateDropdown(row, 180)
    row.mainDropdown:SetPoint("LEFT", row.typeDropdown, "RIGHT", 10, 0)

    return row
end

-- Update type dropdown for a character
function addon:UpdateTypeDropdown(dropdown, character)
    dropdown:SetItems({
        {text = "Unlinked", value = "unlinked"},
        {text = "Main", value = "main"},
        {text = "Alt", value = "alt"},
    })

    -- Set initial selection
    dropdown:SetSelected(character.characterType)

    -- Change handler
    dropdown:SetOnSelect(function(newType)
        local oldType = character.characterType

        -- Validation: Check if changing from main to alt when main has linked alts
        if newType == "alt" and oldType == "main" then
            if WhateverRoyaleDB and WhateverRoyaleDB.characters then
                for _, char in pairs(WhateverRoyaleDB.characters) do
                    if char.mainCharacter == character.characterId then
                        addon:Error("Cannot change to Alt - this character has linked alts")
                        -- Reset dropdown to previous value
                        dropdown:SetSelected(oldType)
                        return
                    end
                end
            end
        end

        character.characterType = newType

        if newType == "main" or newType == "unlinked" then
            character.mainCharacter = nil
        end

        addon:Debug(string.format("Set %s to %s", character.characterId, newType))

        -- Refresh to update main dropdown visibility
        addon:RefreshCharacterList(addon.tabs.mainalt)
    end)
end

-- Update main dropdown for a character
function addon:UpdateMainDropdown(dropdown, character)
    -- Only show for alts
    if character.characterType ~= "alt" then
        dropdown:Hide()
        return
    end

    dropdown:Show()

    -- Build items list
    local items = {{text = "-- Select Main --", value = nil}}

    -- Add all mains
    if WhateverRoyaleDB and WhateverRoyaleDB.characters then
        for _, char in pairs(WhateverRoyaleDB.characters) do
            if char.characterType == "main" and char.characterId ~= character.characterId then
                table.insert(items, {text = char.characterId, value = char.characterId})
            end
        end
    end

    dropdown:SetItems(items)

    -- Set initial selection
    dropdown:SetSelected(character.mainCharacter)

    -- Change handler
    dropdown:SetOnSelect(function(mainId)
        if not mainId then
            -- Unlink
            character.mainCharacter = nil
            addon:Debug(string.format("Unlinked %s from main", character.characterId))
            return
        end

        local canLink, errorMsg = addon:CanLinkCharacters(character.characterId, mainId)
        if not canLink then
            addon:Error(errorMsg)
            -- Reset dropdown to previous value
            dropdown:SetSelected(character.mainCharacter)
            return
        end

        addon:LinkAltToMain(character.characterId, mainId)
    end)
end

-- Save character links (placeholder - changes are auto-saved)
function addon:SaveCharacterLinks(tab)
    addon:Success("All changes have been saved!")
    addon:RefreshCharacterList(tab)

    -- Refresh statistics tab if it exists
    if addon.tabs and addon.tabs.statistics then
        addon:RefreshLeaderboard(addon.tabs.statistics)
    end
end
